/*********************************************************************
* Software License Agreement (BSD License)
*
*  Copyright (c) 2010, Rice University
*  All rights reserved.
*
*  Redistribution and use in source and binary forms, with or without
*  modification, are permitted provided that the following conditions
*  are met:
*
*   * Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer.
*   * Redistributions in binary form must reproduce the above
*     copyright notice, this list of conditions and the following
*     disclaimer in the documentation and/or other materials provided
*     with the distribution.
*   * Neither the name of the Rice University nor the names of its
*     contributors may be used to endorse or promote products derived
*     from this software without specific prior written permission.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
*  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
*  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
*  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
*  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
*  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
*  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
*  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
*  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
*  POSSIBILITY OF SUCH DAMAGE.
*********************************************************************/

/* Author: Mark Moll */

#ifndef OMPL_EXTENSION_VORTEX_STATE_SPACE_
#define OMPL_EXTENSION_VORTEX_STATE_SPACE_

#include "ompl/base/StateSpace.h"
#include "ompl/base/spaces/RealVectorStateSpace.h"
#include "ompl/base/spaces/SO3StateSpace.h"
#include "ompl/extensions/Vortex/VortexEnvironment.h"

namespace Vx
{
    class VxState;
}

namespace ompl
{
    namespace control
    {

        /** \brief State space representing Vortex states */
        class VortexStateSpace : public base::StateSpace
        {
        public:

            enum
                {
                    /** \brief Index of bit in StateType::collision indicating whether it is known if a state is in collision or not. Initially this is 0. The value of this bit is updated by VortexStateSpace::evaluateCollision() and VortexControlSpace::propagate(). */
                    STATE_COLLISION_KNOWN_BIT = 0,
                    /** \brief Index of bit in StateType::collision indicating whether a state is in collision or not. Initially the value of this field is unspecified. The value gains meaning (1 or 0) when VortexStateSpace::STATE_COLLISION_KNOWN_BIT becomes 1. The value of this bit is updated by VortexStateSpace::evaluateCollision() and VortexControlSpace::propagate(). A value of 1 implies that there is no collision for which VortexEnvironment::isValidCollision() returns false. */
                    STATE_COLLISION_VALUE_BIT = 1,
                    /** \brief Index of bit in StateType::collision indicating whether it is known if a state is in valid or not. Initially this is 0. The value of this bit is updated by VortexStateValidityChecker::isValid(). This bit is only used if the VortexStateValidityChecker is used. */
                    STATE_VALIDITY_KNOWN_BIT = 2,
                    /** \brief Index of bit in StateType::collision indicating whether a state is valid or not. Initially the value of this field is unspecified. The value gains meaning (1 or 0) when VortexStateSpace::STATE_VALIDITY_KNOWN_BIT becomes 1. The value of this bit is updated by VortexEnvironment::isValid(). A value of 1 implies that a state is valid. This bit is only used if the VortexStateValidityChecker is used. */
                    STATE_VALIDITY_VALUE_BIT = 3,
                };

            /** \brief Vortex State. This is a compound state that allows accessing the properties of the bodies the state space is constructed for. */
            class StateType : public base::State
            {
            public:
                StateType(void) : vxstate_(NULL), collision_(0)
                {
                }

                Vx::VxState* vxstate_;
                /** \brief Flag containing information about state validity.

                    - BIT 0: (VortexStateSpace::STATE_COLLISION_KNOWN_BIT)
                    - BIT 1: (VortexStateSpace::STATE_COLLISION_VALUE_BIT)
                    - BIT 2: (VortexStateSpace::STATE_VALIDITY_KNOWN_BIT)
                    - BIT 3: (VortexStateSpace::STATE_VALIDITY_VALUE_BIT) */
                mutable int collision_;

            };

            /** \brief Construct a state space representing Vortex states.
                
                A Vortex state should include all movable/controllable objects in
                a VortexEnvironment
                
                \param env the environment to construct the state space for
            */
            VortexStateSpace(const VortexEnvironmentPtr &env);

            virtual ~VortexStateSpace(void)
            {
            }

            /** \brief Get the Vortex environment this state space corresponds to */
            const VortexEnvironmentPtr& getEnvironment(void) const
            {
                return env_;
            }

            /** \brief By default, the volume bounds enclosing the
              geometry of the environment are computed to include all
              objects in the spaces collision checking is performed. */
            void setDefaultBounds(void);

            /** Set a bounding box in workspace that the movable objects are
                allowed to move around in. */
            void setWorkspaceBounds(const base::RealVectorBounds& bounds);

            /** \brief Read the relevant parameters of the Vortex environment
                and store them in \e state. */
            virtual void readState(base::State *state) const;

            /** \brief Set the parameters of the Vortex environment to be the
                ones read from \e state.  The code will technically work if
                this function is called from multiple threads
                simultaneously, but the results are unpredictable. */
            virtual void writeState(const base::State *state) const;

            virtual base::State* allocState(void) const;
            virtual void freeState(base::State *state) const;
            virtual void copyState(base::State *destination, const base::State *source) const;

            /** \brief Fill the VortexStateSpace::STATE_COLLISION_VALUE_BIT of
                StateType::collision member of a state, if unspecified.
                Return the value value of that bit. */
            virtual bool evaluateCollision(const base::State *source) const;

            virtual unsigned int getDimension() const;
            virtual double getMaximumExtent() const;
            virtual void enforceBounds(ompl::base::State*) const
            {
            }
            virtual bool satisfiesBounds(const ompl::base::State*) const
            {
                return true;
            }
            virtual double distance(const ompl::base::State* s0, const ompl::base::State* s1) const
            {
                return s0 == s1 ? 0. : 1.;
            }
            virtual bool equalStates(const ompl::base::State*, const ompl::base::State*) const;
            virtual void interpolate(const ompl::base::State*, const ompl::base::State*, double, ompl::base::State*) const;
            virtual ompl::base::StateSamplerPtr allocStateSampler() const;

        protected:
            /** \brief Return true iff the bounding box of the current state
                stored in env_->assembly_ is within bounds_.
                
                Helper function for evaluateCollision. */
            bool satisfiesWorkspaceBounds() const;

            /** \brief Representation of the Vortex parameters OMPL needs to plan */
            VortexEnvironmentPtr env_;

            /** \brief The bounds of the workspace (used for state validity) */
            ompl::base::RealVectorBounds bounds_;
        };
    }
}


#endif
