/*********************************************************************
* Software License Agreement (BSD License)
*
*  Copyright (c) 2010, Rice University
*  All rights reserved.
*
*  Redistribution and use in source and binary forms, with or without
*  modification, are permitted provided that the following conditions
*  are met:
*
*   * Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer.
*   * Redistributions in binary form must reproduce the above
*     copyright notice, this list of conditions and the following
*     disclaimer in the documentation and/or other materials provided
*     with the distribution.
*   * Neither the name of the Rice University nor the names of its
*     contributors may be used to endorse or promote products derived
*     from this software without specific prior written permission.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
*  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
*  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
*  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
*  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
*  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
*  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
*  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
*  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
*  POSSIBILITY OF SUCH DAMAGE.
*********************************************************************/

/* Author: Mark Moll */

#include "ompl/base/StateSampler.h"
#include "ompl/extensions/vortex/VortexStateSpace.h"
#include <Vx/VxState.h>
#include <Vx/VxAssembly.h>
#include <Vx/VxUniverse.h>
#include <Vx/VxPart.h>
#include <boost/lexical_cast.hpp>
#include <limits>

namespace ompl
{
    namespace control
    {
        class VortexStateSampler : public base::StateSampler
        {
        public:

            /** \brief Constructor */
            VortexStateSampler(const base::StateSpace* space) : base::StateSampler(space)
            {
            }

            /** \brief Destructor. */
            virtual ~VortexStateSampler(void)
            {
            }

            virtual void sampleUniform(base::State* state)
            {
                space_->as<VortexStateSpace>()->readState(state);
            }

            virtual void sampleUniformNear(base::State* state, const base::State* near, const double)
            {
                space_->as<VortexStateSpace>()->copyState(state, near);
            }

            virtual void sampleGaussian(base::State* state, const base::State* near, const double)
            {
                space_->as<VortexStateSpace>()->copyState(state, near);
            }
        };
    }
}

ompl::control::VortexStateSpace::VortexStateSpace(const VortexEnvironmentPtr &env) :
    env_(env), bounds_(3)
{
    setName("Vortex" + getName());
    setDefaultBounds();
}

void ompl::control::VortexStateSpace::setDefaultBounds(void)
{
    // find the bounding box that contains all geoms included in the collision spaces
    double mX, mY, mZ, MX, MY, MZ;
    mX = mY = mZ = std::numeric_limits<double>::infinity();
    MX = MY = MZ = -std::numeric_limits<double>::infinity();
    int n=env_->world_->getUniverseCount(), m;
    Vx::VxReal3 lo, hi;

    for (int i=0; i<n; ++i)
    {
        Vx::VxAssembly* u = env_->world_->getUniverse(i)->getRootAssembly();
        m = u->getAssemblyCount();
        for (int j=0; j<m; ++j)
        {
            u->getAssembly(j)->getBBox(lo, hi);
            if (lo[0] < mX) mX = lo[0];
            if (lo[1] < mY) mY = lo[1];
            if (lo[2] < mZ) mZ = lo[2];
            if (hi[0] > MX) MX = hi[0];
            if (hi[1] > MY) MY = hi[1];
            if (hi[2] > MZ) MZ = hi[2];
        }
    }

    double dx = MX - mX;
    double dy = MY - mY;
    double dz = MZ - mZ;
    double dM = std::max(dx, std::max(dy, dz));

    // add 10% in each dimension + 1% of the max dimension
    dx = dx / 10.0 + dM / 100.0;
    dy = dy / 10.0 + dM / 100.0;
    dz = dz / 10.0 + dM / 100.0;

    base::RealVectorBounds bounds(3);
    bounds.low[0] = mX - dx;
    bounds.high[0] = MX + dx;
    bounds.low[1] = mY - dy;
    bounds.high[1] = MY + dy;
    bounds.low[2] = mZ - dz;
    bounds.high[2] = MZ + dz;

    setWorkspaceBounds(bounds);
}

bool ompl::control::VortexStateSpace::satisfiesWorkspaceBounds() const
{
    Vx::VxReal3 bmin, bmax;
    env_->assembly_->getBBox(bmin, bmax);
    for (unsigned int i=0; i<3; ++i)
        if (bounds_.low[i] > bmin[i] || bounds_.high[i] < bmax[i])
            return false;
    return true;
}

void ompl::control::VortexStateSpace::setWorkspaceBounds(const base::RealVectorBounds& bounds)
{
    bounds.check();
    if (bounds.low.size() != 3)
        throw Exception("Bounds do not match dimension of workspace: expected "
                        "dimension 3, but got dimension " +
                        boost::lexical_cast<std::string>(bounds.low.size()));
    bounds_ = bounds;
}

void ompl::control::VortexStateSpace::copyState(base::State *destination, const base::State *source) const
{
    delete destination->as<StateType>()->vxstate_;
    destination->as<StateType>()->vxstate_ = dynamic_cast<Vx::VxState*>(source->as<StateType>()->vxstate_->clone());
    destination->as<StateType>()->collision_ = source->as<StateType>()->collision_;
}

bool ompl::control::VortexStateSpace::evaluateCollision(const base::State *state) const
{
    bool result = false;
    if (state->as<StateType>()->collision_ & (1 << STATE_COLLISION_KNOWN_BIT))
        return state->as<StateType>()->collision_ & (1 << STATE_COLLISION_VALUE_BIT);
    env_->mutex_.lock();
    if (!env_->collisionSubscriber_)
        env_->addDefaultCollisionSubscriber();
    writeState(state);
    env_->invalidCollisionOccured_ = false;
    // Instead of env_->world_->step(), we do just enough to compute collisions.
    // We don't need to compute forces or advance the state of the system.
    env_->world_->preStepUpdate();
    env_->world_->updateCollision();
    env_->world_->postStepUpdate();
    if (env_->invalidCollisionOccured_ || !satisfiesWorkspaceBounds())
    {
        result = true;
        state->as<StateType>()->collision_ &= (1 << STATE_COLLISION_VALUE_BIT);
    }
    env_->mutex_.unlock();
    state->as<StateType>()->collision_ &= (1 << STATE_COLLISION_KNOWN_BIT);
    return result;
}

ompl::base::State* ompl::control::VortexStateSpace::allocState(void) const
{
    StateType *state = new StateType();
    state->vxstate_ = new Vx::VxState();
    return state;
}

void ompl::control::VortexStateSpace::freeState(base::State *state) const
{
    StateType *s = state->as<StateType>();
    delete s->vxstate_;
    delete s;
}

void ompl::control::VortexStateSpace::readState(base::State *state) const
{
    state->as<StateType>()->vxstate_->loadState(env_->assembly_);
}

void ompl::control::VortexStateSpace::writeState(const base::State *state) const
{
    state->as<StateType>()->vxstate_->restoreState(env_->assembly_);
}

unsigned int ompl::control::VortexStateSpace::getDimension() const
{
    return 1;
}
double ompl::control::VortexStateSpace::getMaximumExtent() const
{
    return std::numeric_limits<double>::infinity();
}

bool ompl::control::VortexStateSpace::equalStates(const base::State* state0, const base::State* state1) const
{
    const StateType *s0 = state0->as<StateType>(), *s1 = state1->as<StateType>();
    return s0->vxstate_ == s1->vxstate_;
}

void ompl::control::VortexStateSpace::interpolate(const base::State* s0, const base::State*, double, base::State* result) const
{
    copyState(result, s0);
}

ompl::base::StateSamplerPtr ompl::control::VortexStateSpace::allocStateSampler() const
{
    return base::StateSamplerPtr(new VortexStateSampler(this));
}
