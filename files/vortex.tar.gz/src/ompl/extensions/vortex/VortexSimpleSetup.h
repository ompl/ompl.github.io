/*********************************************************************
* Software License Agreement (BSD License)
*
*  Copyright (c) 2010, Rice University
*  All rights reserved.
*
*  Redistribution and use in source and binary forms, with or without
*  modification, are permitted provided that the following conditions
*  are met:
*
*   * Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer.
*   * Redistributions in binary form must reproduce the above
*     copyright notice, this list of conditions and the following
*     disclaimer in the documentation and/or other materials provided
*     with the distribution.
*   * Neither the name of the Rice University nor the names of its
*     contributors may be used to endorse or promote products derived
*     from this software without specific prior written permission.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
*  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
*  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
*  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
*  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
*  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
*  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
*  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
*  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
*  POSSIBILITY OF SUCH DAMAGE.
*********************************************************************/

/* Author: Mark Moll */

#ifndef OMPL_EXTENSION_VORTEX_SIMPLE_SETUP_
#define OMPL_EXTENSION_VORTEX_SIMPLE_SETUP_

#include "ompl/control/SimpleSetup.h"
#include "ompl/extensions/vortex/VortexStateValidityChecker.h"
#include "ompl/extensions/vortex/VortexControlSpace.h"

namespace ompl
{

    namespace control
    {

        /** \brief Create the set of classes typically needed to solve a
            control problem when forward propagation is computed with Vortex. */
        class VortexSimpleSetup : public SimpleSetup
        {
        public:

            /** \brief Constructor needs the control space needed for planning. */
            explicit
            VortexSimpleSetup(const ControlSpacePtr &space);

            /** \brief The control space is assumed to be VortexControlSpace.
                Constructor only needs the state space. */
            explicit
            VortexSimpleSetup(const base::StateSpacePtr &stateSpace);

            /** \brief The control space is assumed to be
                VortexControlSpace. The state space is assumed to
                be VortexStateSpace. Constructor only needs the Vortex
                environment. */
            explicit
            VortexSimpleSetup(const VortexEnvironmentPtr &env);

            /** \brief Get the Vortex environment associated to the state and control state space */
            const VortexEnvironmentPtr& getEnvironment(void) const
            {
                return getStateSpace()->as<VortexStateSpace>()->getEnvironment();
            }

            /** \brief Get the current Vortex state (read parameters from Vortex bodies) */
            base::ScopedState<VortexStateSpace> getCurrentState(void) const;

            /** \brief Set the current Vortex state (set parameters for Vortex bodies) */
            void setCurrentState(const base::ScopedState<> &state);

            /** \brief Set the current Vortex state (set parameters for Vortex bodies) */
            void setCurrentState(const base::State *state);

            /** \brief Set the Vortex world to the states that are
                contained in a given path, sequentially. Using \e
                timeFactor, the speed at which this sequence is
                iterated through is altered.

                \return true whenever the visualizer is still running. */
            bool playPath(const base::PathPtr &path, double timeFactor = 1.0) const;

            /** \brief Call playPath() on the solution path, if one is available.

                \return true whenever the visualizer is still running. */
            bool playSolutionPath(double timeFactor = 1.0) const;

            /** \brief Simulate the Vortex environment forward for \e duration
                seconds, using the control \e control. Construct a path
                representing this action. */
            base::PathPtr simulateControl(const double* control, double duration) const;

            /** \brief Simulate the Vortex environment forward for \e duration
                seconds, using the control \e control. Construct a path
                representing this action. */
            base::PathPtr simulateControl(const Control* control, double duration) const;

            /** \brief Simulate the Vortex environment forward for \e
                duration seconds, using the null control
                (ompl::control::ControlSpace::nullControl()).
                Construct a path representing this action. */
            base::PathPtr simulate(double duration) const;

            virtual void setup(void);

        private:

            void useEnvParams(void);

        };
    }

}
#endif
